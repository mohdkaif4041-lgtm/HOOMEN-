import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ShoppingCart } from "lucide-react";
import { motion } from "framer-motion";

export default function ClothingStore() {
  const products = [
    { id: 1, name: "Classic Hoodie", price: "$49", image: "https://images.unsplash.com/photo-1520975922321-5c2f74b6a9c0" },
    { id: 2, name: "Streetwear Tee", price: "$29", image: "https://images.unsplash.com/photo-1520974735194-1a5c0d2a0a63" },
    { id: 3, name: "Denim Jacket", price: "$89", image: "https://images.unsplash.com/photo-1541099649105-f69ad21f3246" },
  ];

  return (
    <div className="min-h-screen bg-neutral-50">
      <nav className="flex items-center justify-between px-8 py-4 shadow-sm bg-white">
        <h1 className="text-2xl font-bold tracking-wide">HOOMEN</h1>
        <Button className="rounded-2xl flex gap-2">
          <ShoppingCart size={18} /> Cart
        </Button>
      </nav>

      <section className="grid md:grid-cols-2 gap-8 px-8 py-20 items-center">
        <motion.div initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }}>
          <h2 className="text-5xl font-extrabold mb-6">
            Modern Fashion
            <span className="block text-neutral-500">Built for HOOMEN</span>
          </h2>
          <p className="mb-6 text-lg text-neutral-600">
            HOOMEN is an Instagram-first fashion brand delivering clean streetwear with attitude.
          </p>
          <Button className="rounded-2xl px-8 py-6 text-lg">
            Shop via Instagram
          </Button>
        </motion.div>
        <motion.img
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d"
          className="rounded-2xl shadow-lg"
        />
      </section>

      <section className="px-8 py-16">
        <h3 className="text-3xl font-bold mb-10">Featured Products</h3>
        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-8">
          {products.map((p) => (
            <Card key={p.id} className="rounded-2xl overflow-hidden shadow-md">
              <img src={p.image} className="h-64 w-full object-cover" />
              <CardContent className="p-4">
                <h4 className="font-semibold text-lg">{p.name}</h4>
                <p className="text-neutral-500 mb-4">{p.price}</p>
                <Button className="w-full rounded-xl">Add to Cart</Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <footer className="bg-white border-t px-8 py-6 text-center text-neutral-500">
        © 2025 HOOMEN. All rights reserved.
      </footer>
    </div>
  );
}
